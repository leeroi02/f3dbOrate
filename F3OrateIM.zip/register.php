<?php
  include 'connect.php';
  //include 'readrecords.php';
  // require_once 'includes/header.php';
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css"/>
    <title>Curious KeyPie - Registration</title>
</head>
<body class="wow">
 
<header>
    <a href="" class="logo">
        <i class='bx bxs-site'></i>Curious KeyPie
    </a>
 
    <ul class="navbar">
        <li><a href="index.php" class="home-active">Home</a></li>
        <li><a href="aboutus.php">About Us</a></li>
        <li><a href="contactus.php">Contact Us</a></li>
    </ul>
 
    <a href="login.html" class="btn"> Log In</a>
    <a href="register.php" class="btn"> Registration</a>
</header>
 
<div class="wow">
    <div class="container">
        <p class="form-title">REGISTRATION</p>
        <form action="register.php" method="post">
            <div class="main-user-info">
                <div class="user-input-box">
                    <label for="firstName">First Name</label>
                    <input type="text" id="firstName" name="txtfirstname" placeholder="Enter First Name"/>
                </div>
 
                <div class="user-input-box">
                    <label for="lastName">Last Name</label>
                    <input type="text" id="lastName" name="txtlastname" placeholder="Enter Last Name"/>
                </div>
 
                <div class="user-input-box">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="txtusername" placeholder="Enter Username"/>
                </div>
 
                <div class="user-input-box">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="txtemail" placeholder="Enter Email"/>
                </div>
 
                <div class="user-input-box">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="txtpassword" placeholder="Enter Password"/>
                </div>
 
                <div class="user-input-box">
                    <label for="confirmPassword">Confirm Password</label>
                    <input type="password" id="confirmPassword" name="txtpassword" placeholder="Confirm Password"/>
                </div>
            </div>
 
            <div class="gender-details-box">
                <span class="gender-title">Gender</span>
                <div class="gender-category">
                    <input type="radio" name="txtgender" id="male" value="Male">
                    <label for="male">Male</label>
                    <input type="radio" name="txtgender" id="female" value="Female">
                    <label for="female">Female</label>
                    <input type="radio" name="txtgender" id="other" value="Other">
                    <label for="other">Other</label>
                </div>
            </div>
 
            <div class="form-submit-btn">
                <input type="submit" name="btnRegister" value="Register">
            </div>
        </form>
    </div>
 
    <footer>
        <div class="footer_content">
            <div class="fillers">
                <a href="#" class="footer-link">Zedric Marc D. Tabinas</a>
                <a href="#" class="footer-link">BSCS - 2</a>
            </div>
        </div>
    </footer>
</div>
 
</body>
</html>
 
 
<?php
include 'connect.php';
 
if(isset($_POST['btnRegister'])){      
    $fname = mysqli_real_escape_string($connection, $_POST['txtfirstname']);
    $lname = mysqli_real_escape_string($connection, $_POST['txtlastname']);
    $gender = mysqli_real_escape_string($connection, $_POST['txtgender']);
    $email = mysqli_real_escape_string($connection, $_POST['txtemail']);
    $uname = mysqli_real_escape_string($connection, $_POST['txtusername']);
    $pword = mysqli_real_escape_string($connection, $_POST['txtpassword']);
 
    // Validate passwords match
    /* if ($pword != $confirmpword) {
        echo "<script language='javascript'>
                    alert('Passwords do not match.');
              </script>";
    } else { */
        // Hash the password
        $hashedPassword = password_hash($pword, PASSWORD_DEFAULT);
 
        // Save data to tbluserprofile          
        $sql1 = "INSERT INTO tbluserprofile(firstname, lastname, gender) VALUES ('$fname', '$lname', '$gender')";
        mysqli_query($connection, $sql1);
 
        // Check tbluseraccount if username is already existing. Save info if false. Prompt msg if true.
        $sql2 = "SELECT * FROM tbluseraccount WHERE username = '$uname'";
        $result = mysqli_query($connection, $sql2);
        $row = mysqli_num_rows($result);
 
        if($row == 0){
            $sql ="INSERT INTO tbluseraccount(emailadd, username, password) VALUES ('$email', '$uname', '$hashedPassword')";
            mysqli_query($connection, $sql);
            echo "<script language='javascript'>
                        alert('New record saved.');
                  </script>";
        } else {
            echo "<script language='javascript'>
                        alert('Username already existing');
                  </script>";
        }
    }
?>