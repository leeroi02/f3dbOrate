<?php
    include 'connect.php';
?>

<link rel="stylesheet" href="css/indexstyle.css"/>
  
    <header>
        <a href=""class="logo">
            <i class='bx bxs-site'></i>Curious KeyPie
        </a>

        <ul class="navbar">
            <li><a href="file:///C:/Users/L11Y14W25/Desktop/index.html"class="home-active">Home </a></li>
            <li><a href="http://127.0.0.1:5500/about.html">About Us</a></li>
            <li><a href="#contact">Contact Us </a></li>
        </ul>

            <a href="login.php" class="btn"> Log In</a>
            <a href="register.php" class="btn"> Registration</a>
            
    </header>

    <section class="about">
        <img src="ckp2.png" alt="Curious KeyPie Image">
    </section>

    <footer>
        <p> Felicity Orate <br> Zedric Marc Tabinas <br> BSCS - 2</p>
    </footer>
